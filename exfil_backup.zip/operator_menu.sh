#!/data/data/com.termux/files/usr/bin/bash

LOG_FILE="$HOME/exfil/.logs/exfil.log"
EXFIL_DIR="$HOME/exfil"

mkdir -p "$HOME/exfil/.logs"

function log_event() {
    local msg="$1"
    local timestamp
    timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] $msg" >> "$LOG_FILE"
}

function deploy_payload_lab() {
    echo "[*] Launching in Lab Mode..."
    python3 "$EXFIL_DIR/stage_1_dropper.py" --lab --consent
    log_event "Lab Mode payload deployed"
}

function deploy_payload_field() {
    echo "[*] Launching in Field Mode..."
    python3 "$EXFIL_DIR/stage_1_dropper.py" --field --consent
    log_event "Field Mode payload deployed"
}

function trigger_manual_exfil() {
    echo "[*] Triggering manual exfiltration..."
    python3 "$EXFIL_DIR/exfil_launcher.py" --field
    log_event "Manual exfiltration triggered"
}

function view_logs() {
    echo "[*] Showing live logs. Press Ctrl+C to stop."
    tail -f "$LOG_FILE"
}

function self_destruct() {
    echo "[!] Executing self-destruct sequence..."
    bash "$EXFIL_DIR/self_destruct_loader.sh"
    log_event "Self-destruct sequence activated"
}

function kill_switch() {
    echo "[!] Kill-switch triggered..."
    python3 "$EXFIL_DIR/stage_1_dropper.py" --kill
    log_event "Kill-switch executed"
}

function main_menu() {
    clear
    echo -e "\e[1;36m┌──────────────────────────────┐"
    echo -e "│  Session Exfil Operator   │"
    echo -e "└──────────────────────────────┘\e[0m"
    echo "[1] Deploy Payload (Lab Mode)"
    echo "[2] Deploy Payload (Field Mode)"
    echo "[3] Trigger Manual Exfil"
    echo "[4] View Logs"
    echo "[5] Wipe / Self-Destruct"
    echo "[6] Kill-Switch Trigger"
    echo "[0] Exit"
    echo -n "Select > "
    read -r choice

    case "$choice" in
        1) deploy_payload_lab ;;
        2) deploy_payload_field ;;
        3) trigger_manual_exfil ;;
        4) view_logs ;;
        5) self_destruct ;;
        6) kill_switch ;;
        0) echo "Exiting..."; exit 0 ;;
        *) echo "[!] Invalid option" ;;
    esac

    echo ""
    echo "Press Enter to return to menu..."
    read -r
    main_menu
}

main_menu
