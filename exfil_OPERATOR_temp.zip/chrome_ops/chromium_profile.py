
import os
import shutil

def init_profile(profile_path):
    if os.path.exists(profile_path):
        shutil.rmtree(profile_path)
    os.makedirs(profile_path)
