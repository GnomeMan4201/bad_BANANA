
from chrome_ops.chromium_profile import init_profile

if __name__ == "__main__":
    print("[*] Initializing Chromium profile...")
    init_profile("/tmp/chrome_profile")
    print("[*] Done.")
