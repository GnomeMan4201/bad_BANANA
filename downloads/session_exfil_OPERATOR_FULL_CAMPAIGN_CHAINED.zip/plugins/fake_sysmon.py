def simulate():
    print("[sysmon] Registered service running... collecting event logs...")
