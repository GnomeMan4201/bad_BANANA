def grab():
    return "sessionid=abc123; user=admin;"
