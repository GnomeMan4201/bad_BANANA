import time
def decoy_ui():
    print("[System Monitor] Chrome CPU: 1.2%, Memory: 4.5%")
    time.sleep(2)